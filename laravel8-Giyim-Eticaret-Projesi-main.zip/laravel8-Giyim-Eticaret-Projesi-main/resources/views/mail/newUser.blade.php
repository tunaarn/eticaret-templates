<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<tr>
    <td>
        <table border="0" width="600" cellspacing="0" cellpadding="0" align="center">
            <tbody>
            <tr>
                <td style="padding:40px 0;border:1px solid #f2f2f2;border-radius:5px" bgcolor="#fafafa">
                    <table border="0" width="480" cellspacing="0" cellpadding="0" align="center">
                        <tbody>
                        <tr>
                            <td style="line-height:1;color:#3c3c3c;font-size:21px;font-weight:600;font-family:'Open Sans',Helvetica,sans-serif" align="left">
                                <div><span>Sayın {{$name}} Adlı Yeni Üyemiz,</span></div>
                            </td>
                        </tr>
                        <tr>
                            <td height="30">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="line-height:1;color:#3c3c3c;font-size:18px;font-weight:600;font-family:'Open Sans',Helvetica,sans-serif" align="left">
                                <div><span>Kayıt işleminiz onaylanmıştır.</span></div>
                            </td>
                        </tr>
                        <tr>
                            <td height="25">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="line-height:1.8;color:#3c3c3c;font-size:16px;font-weight:400;font-family:'Open Sans',Helvetica,sans-serif" align="left">
                                <div><span>Kayıt olup ve bizi tercih ettiğiniz için teşekkür ederiz.</span></div>
                            </td>
                        </tr>
                        <tr>
                            <td height="25">&nbsp;</td>
                        </tr>
                        <tr>
                            <td align="center"><img style="display:block;line-height:0;font-size:0;border:0" src="https://ci5.googleusercontent.com/proxy/9fCkmQMDLs5RqHZr1dbEELIuxidgeyFWnjoZ_K1v1UodE_fxmm0rMmdHpYScVrIx_e28B-vRxNHm2YOiQy3234iAvZUxsQOa9jAh_L5R3TFWNOuyRuF5YVXQt3SamWmdYQ1P9QL_LrM=s0-d-e1-ft#https://www.veridyen.com/email-resources/assets/images/icons/icons8-debit-card-50.png" alt="Ödeme Yöntemi" border="0" class="CToWUd" data-bit="iit"></td>
                        </tr>
                        <tr>
                            <td height="25">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="line-height:1.8;color:#3c3c3c;font-size:16px;font-weight:400;font-family:'Open Sans',Helvetica,sans-serif" align="left">
                                <div><span>Lütfen bir sonraki aşama olarak hesap ayarlarınızı yapınız ve güvenli şekilde alışverişin tadını çıkarın<br></span></div>
                            </td>
                        </tr>
                        <tr>
                            <td height="25">&nbsp;</td>
                        </tr>
                        <tr>
                            <td style="line-height:1;color:#6a6a6a;font-style:italic;font-size:14px;font-weight:400;font-family:'Open Sans',Helvetica,sans-serif" align="center">
                                <div><span>Sistem Kurucusu <b>Alp Eren Özdemir</b></span></div>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            </tbody>
        </table>
    </td>
</tr>
</body>
</html>
